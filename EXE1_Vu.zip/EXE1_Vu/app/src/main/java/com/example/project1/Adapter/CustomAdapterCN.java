package com.example.project1.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.project1.GiaoDien.ChiTietActivity;
import com.example.project1.R;
import com.example.project1.Model.CongNhan;

import java.util.ArrayList;
import java.util.Locale;

public class CustomAdapterCN extends ArrayAdapter {
    Context context;
    int resource;
    ArrayList<CongNhan> data;
    ArrayList<CongNhan> data_DS;
    public CustomAdapterCN(Context context, int resource, ArrayList<CongNhan> data) {
        super(context, resource);
        this.context=context;
        this.data= data;
        this.resource=resource;

    }

    @Override
    public int getCount() {
        return data.size();
    }
    private static class Holder {
        TextView tvMaCN;
        TextView tvHoTenCN;
        TextView tvPhanXuong;
        ImageView imgChiTiet;
    }

    @Override
    public View getView(int position, View convertView,ViewGroup parent) {
        View view = convertView;
        Holder holder = null;
        if (view == null) {
            holder = new Holder();
            view = LayoutInflater.from(context).inflate(resource, null);
            holder.tvMaCN= view.findViewById(R.id.tvMaCN);
            holder.tvHoTenCN= view.findViewById(R.id.tvHoTenCN);
            holder.tvPhanXuong= view.findViewById(R.id.tvPhanXuong);
            holder.imgChiTiet= view.findViewById(R.id.imgChiTiet);
            view.setTag(holder);
        } else
            holder = (Holder) view.getTag();

        final CongNhan congNhan = data.get(position);

        holder.tvMaCN.setText(congNhan.getMaCN());
        holder.tvHoTenCN.setText(congNhan.getHoCN() + congNhan.getTenCN());
        holder.tvPhanXuong.setText(congNhan.getPhanXuong());
        holder.imgChiTiet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent((Activity) context, ChiTietActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("ma", congNhan.getMaCN());
                intent.putExtras(bundle);
                ((Activity) context).startActivity(intent);


            }
        });
        return  view;
    }
    public void filter(String charText) {
        charText = charText.toLowerCase(Locale.getDefault());
        data.clear();
        if (charText.length() == 0) {
            data.addAll(data_DS);
        } else {
            for (CongNhan model : data_DS) {
                if (model.getMaCN().toLowerCase(Locale.getDefault())
                        .contains(charText)) {
                    data.add(model);
                }
            }
        }
        notifyDataSetChanged();
    }
}
