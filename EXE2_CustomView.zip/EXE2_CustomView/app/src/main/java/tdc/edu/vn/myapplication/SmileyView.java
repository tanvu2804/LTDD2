package tdc.edu.vn.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class SmileyView extends View {
    private Paint mCirclePaint;
    private Paint mCirclePaint1;
    private Paint mEyeAndMouthPaint;
    private Paint mEyeAndMouthPaint1;

    private float mCenterX;
    private float mCenterY;
    private float mRadius;
    private RectF mArcBounds = new RectF();
    Paint paint = new Paint();
    Path path = new Path();

    public SmileyView(Context context) {
        this(context, null);
    }

    public SmileyView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public SmileyView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initPaints();
    }

    private void initPaints() {
        mCirclePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mCirclePaint.setStyle(Paint.Style.FILL);
        mCirclePaint.setColor(Color.BLUE);
        mCirclePaint1 = new Paint(Paint.ANTI_ALIAS_FLAG);
        mCirclePaint1.setStyle(Paint.Style.FILL);
        mCirclePaint1.setColor(Color.WHITE);
        mEyeAndMouthPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mEyeAndMouthPaint.setStyle(Paint.Style.STROKE);
        mEyeAndMouthPaint.setStrokeWidth(5 * getResources().getDisplayMetrics().density);
        mEyeAndMouthPaint.setStrokeCap(Paint.Cap.ROUND);
        mEyeAndMouthPaint.setColor(Color.BLACK);
        mEyeAndMouthPaint1 = new Paint(Paint.ANTI_ALIAS_FLAG);
        mEyeAndMouthPaint1.setStyle(Paint.Style.FILL);
        mEyeAndMouthPaint1.setStrokeWidth(5 * getResources().getDisplayMetrics().density);
        mEyeAndMouthPaint1.setStrokeCap(Paint.Cap.ROUND);
        mEyeAndMouthPaint1.setColor(Color.RED);
        paint.setColor(Color.BLACK);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int w = MeasureSpec.getSize(widthMeasureSpec);
        int h = MeasureSpec.getSize(heightMeasureSpec);

        int size = Math.min(w, h);
        setMeasuredDimension(size, size);
    }
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        mCenterX = w / 2f;
        mCenterY = h / 1.5f;
        mRadius = Math.min(w, h) / 2f;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        // draw face
        canvas.drawCircle(mCenterX, mCenterY, mRadius, mCirclePaint);

        // draw eyes
        float eyeRadius = mRadius / 5f;
        float eyeOffsetX = mRadius / 3f;
        float eyeOffsetY = mRadius / 3f;
        canvas.drawCircle(mCenterX, mCenterY + eyeOffsetY, mRadius * 2f / 2.5f, mCirclePaint1);
        canvas.drawCircle(mCenterX - eyeOffsetX, mCenterY - eyeOffsetY, eyeRadius, mCirclePaint1);
        canvas.drawCircle(mCenterX + eyeOffsetX, mCenterY - eyeOffsetY, eyeRadius, mCirclePaint1);
        canvas.drawCircle(mCenterX - eyeOffsetX, mCenterY - eyeOffsetY, eyeRadius, mEyeAndMouthPaint);
        canvas.drawCircle(mCenterX - eyeOffsetX, mCenterY - eyeOffsetY, eyeRadius / 5f, mEyeAndMouthPaint);
        canvas.drawCircle(mCenterX + eyeOffsetX, mCenterY - eyeOffsetY, eyeRadius, mEyeAndMouthPaint);
        canvas.drawCircle(mCenterX + eyeOffsetX, mCenterY - eyeOffsetY, eyeRadius / 5f, mEyeAndMouthPaint);
        //draw rect
        canvas.drawLine(mCenterX,mCenterY - 40,mCenterX,mCenterY + 125, mEyeAndMouthPaint);
        canvas.drawLine(mCenterX - 225,mCenterY - 20,mCenterX - 125,mCenterY + 20, mEyeAndMouthPaint);
        canvas.drawLine(mCenterX - 230,mCenterY + 40,mCenterX - 125,mCenterY + 45, mEyeAndMouthPaint);
        canvas.drawLine(mCenterX - 225,mCenterY + 100,mCenterX - 125,mCenterY + 70, mEyeAndMouthPaint);
        canvas.drawLine(mCenterX + 225,mCenterY - 20,mCenterX + 125,mCenterY + 20, mEyeAndMouthPaint);
        canvas.drawLine(mCenterX + 230,mCenterY + 40,mCenterX + 125,mCenterY + 45, mEyeAndMouthPaint);
        canvas.drawLine(mCenterX + 225,mCenterY + 100,mCenterX + 125,mCenterY + 70, mEyeAndMouthPaint);

        //
        canvas.drawCircle(mCenterX, mCenterY - eyeOffsetY / 2f, eyeRadius / 3f, mEyeAndMouthPaint1);
        // draw mouth
        float mouthInset = mRadius / 3f;
        mArcBounds.set(mouthInset, mouthInset, mRadius * 2 - mouthInset, mRadius * 2 - mouthInset / 3f);
        canvas.drawArc(mArcBounds, 45f, 90f, false, mEyeAndMouthPaint1);
        canvas.drawPath(path, paint);
    }

    public boolean onTouchEvent(MotionEvent event){
        int eventAction = event.getAction();

        // you may need the x/y location
        float eventX = (float) event.getX();
        float eventY = (float) event.getY();

        // put your code in here to handle the event
        switch (eventAction) {
            case MotionEvent.ACTION_DOWN:
                path.moveTo(eventX, eventY);
                return true;
            case MotionEvent.ACTION_MOVE:
                path.lineTo(eventX, eventY);
                break;
            case MotionEvent.ACTION_UP:
                path.addCircle(eventX, eventY, 10, Path.Direction.CW);
                break;
            case MotionEvent.ACTION_CANCEL: {
                path.addCircle(eventX, eventY, 10, Path.Direction.CW);
                break;
            }
            default:
                return false;

        }

        // tell the View to redraw the Canvas
        invalidate();

        // tell the View that we handled the event
        return true;
    }
}

