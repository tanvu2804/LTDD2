package com.example.abc;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity  implements SensorEventListener {
    SensorManager sensorManager;
    int i = 1;
    TextView txtView;
    ImageView imgColor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setControl();
        setEvent();
    }

    private void setControl() {
        txtView = (TextView) findViewById(R.id.textView);
        imgColor = (ImageView) findViewById(R.id.imgColor);
    }

    private void setEvent() {
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        sensorManager.registerListener(this,sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT),SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {

        if (event.sensor.getType() == Sensor.TYPE_LIGHT){
            // doi hinh
            layVecTorvathaydoitext(event);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }


    public void layVecTorvathaydoitext(SensorEvent event){


        float values = event.values[0];
        txtView.setText("" + values);
        if (values > 0 && values < 100)
        {
            imgColor.setBackgroundResource(R.color.cl1);
        }
        else if (values >= 100 && values < 200)
        {
            imgColor.setBackgroundResource(R.color.cl2);
        }
        else if (values >= 200 && values < 300)
        {
            imgColor.setBackgroundResource(R.color.cl3);
        }
        else if (values >= 300 && values < 400)
        {
            imgColor.setBackgroundResource(R.color.cl4);
        }
        else if (values >= 400 && values < 500)
        {
            imgColor.setBackgroundResource(R.color.cl5);
        }
        else if (values >= 500 && values < 600)
        {
            imgColor.setBackgroundResource(R.color.cl6);
        }
       else if (values >= 600 && values < 700)
        {
            imgColor.setBackgroundResource(R.color.cl7);
        }
        else if (values >= 700 && values < 800)
        {
            imgColor.setBackgroundResource(R.color.cl8);
        }
        else
        {
            imgColor.setBackgroundResource(R.color.cl9);
        }
    }

}

