package com.example.project.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.project.GiaoDien.ChiTietActivity;
import com.example.project.Model.ChiTietChamCong;
import com.example.project.Model.SanPham;
import com.example.project.R;

import java.util.ArrayList;
import java.util.Locale;

public class CustomAdapterIn extends ArrayAdapter {
    Context context;
    int resource;
    ArrayList<ChiTietChamCong> data;
    ArrayList<SanPham> data_sp;
    ArrayList<ChiTietChamCong> data_DS;
    public CustomAdapterIn(Context context, int resource, ArrayList<ChiTietChamCong> data, ArrayList<SanPham> data_sp) {
        super(context, resource);
        this.context=context;
        this.data= data;
        this.resource=resource;
        this.data_sp = data_sp;
    }

    @Override
    public int getCount() {
        return data.size();
    }
    private static class Holder {
        TextView tvSTT;
        TextView tvMaSP;
        TextView tvTenSP;
        TextView tvSTP;
        TextView tvSPP;
        TextView tvTC;
        TextView tvTT;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        Holder holder = null;
        if (view == null) {
            holder = new Holder();
            view = LayoutInflater.from(context).inflate(resource, null);
            holder.tvSTT= view.findViewById(R.id.tvSTP);
            holder.tvMaSP= view.findViewById(R.id.tvMaSP);
            holder.tvTenSP= view.findViewById(R.id.tvTenSP);
            holder.tvSTP= view.findViewById(R.id.tvSTP);
            holder.tvSPP= view.findViewById(R.id.tvSPP);
            holder.tvTC= view.findViewById(R.id.tvTC);
            holder.tvTT= view.findViewById(R.id.tvTT);

            view.setTag(holder);
        } else
            holder = (Holder) view.getTag();

        final ChiTietChamCong chiTietChamCong = data.get(position);
        final SanPham sanPham = data_sp.get(position);
        holder.tvSTT.setText(chiTietChamCong.getMaCc());
        holder.tvMaSP.setText(sanPham.getMaSP());
        holder.tvTenSP.setText(sanPham.getTenSP());
        holder.tvSTP.setText(chiTietChamCong.getStp());
        holder.tvSPP.setText(chiTietChamCong.getSpp());
        holder.tvTC.setText(sanPham.getDonGia());
        holder.tvTT.setText(sanPham.getDonGia());

        return  view;
    }
    public void filter(String charText) {
        charText = charText.toLowerCase(Locale.getDefault());
        data.clear();
        if (charText.length() == 0) {
            data.addAll(data_DS);
        } else {
            for (ChiTietChamCong model : data_DS) {
                if (model.getMaCc().toLowerCase(Locale.getDefault())
                        .contains(charText)) {
                    data.add(model);
                }
            }
        }
        notifyDataSetChanged();
    }
}
