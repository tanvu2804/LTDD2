package com.example.project.GiaoDien;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.project.Adapter.CustomAdapterCN;
import com.example.project.Adapter.CustomAdapterIn;
import com.example.project.DataBase.DBChiTietChamCong;
import com.example.project.DataBase.DBCongNhan;
import com.example.project.DataBase.DBSanPham;
import com.example.project.Model.ChiTietChamCong;
import com.example.project.Model.SanPham;
import com.example.project.R;

import java.util.ArrayList;

public class InActivity extends AppCompatActivity {
    ListView lvIn;
    DBSanPham dbSanPham = new DBSanPham(this);
    DBChiTietChamCong dbChiTietChamCong = new DBChiTietChamCong(this);
    ArrayList<SanPham> data_sp = new ArrayList<>();
    ArrayList<ChiTietChamCong> data_ct = new ArrayList<>();
    ArrayAdapter adapter_in;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_in);
        setControl();
        setEvent();
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
    }
    private void setEvent() {

        try {
            String ma = getIntent().getExtras().getString("macc");
            data_ct = dbChiTietChamCong.LayDL(ma);
            data_sp = dbSanPham.LayDL();
            adapter_in = new CustomAdapterIn(this, android.R.layout.simple_spinner_item, data_ct, data_sp);
        } catch (Exception ex) {
        }

    }
    private void setControl() {
        lvIn = findViewById(R.id.lvIn);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}