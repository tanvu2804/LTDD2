package com.example.project.Model;

public class ChiTietChamCong {
    String maCc;
    String Stp;
    String Spp;
    String SanPham;

    public String getMaCc() {
        return maCc;
    }

    public void setMaCc(String maCc) {
        this.maCc = maCc;
    }

    public String getStp() {
        return Stp;
    }

    public void setStp(String stp) {
        Stp = stp;
    }

    public String getSpp() {
        return Spp;
    }

    public void setSpp(String spp) {
        Spp = spp;
    }

    public String getSanPham() {
        return SanPham;
    }

    public void setSanPham(String sanPham) {
        SanPham = sanPham;
    }

    @Override
    public String toString() {
        return "ChamCong{" +
                "maCc='" + maCc + '\'' +
                ", Stp='" + Stp + '\'' +
                ", Spp='" + Spp + '\'' +
                ", SanPham='" + SanPham + '\'' +
                '}';
    }
}
